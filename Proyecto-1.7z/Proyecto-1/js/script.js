function screen()
{
    let view1 = document.getElementById("view1");
    let view2 = document.getElementById("view2");
    let view3 = document.getElementById("view3");
    let view4 = document.getElementById("view4");
    let height = body.screen.height;

    view1.style.height = height;
}